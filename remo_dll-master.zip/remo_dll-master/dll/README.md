# README #

This is the Remo DLL for Windows. I cleaned the repository and removed everything except the version n9 present in the bitbucket repository.
